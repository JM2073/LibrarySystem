﻿using System.Windows.Controls;

namespace Main.Views
{
    public partial class AddUserView : UserControl
    {
        public AddUserView()
        {
            InitializeComponent();
        }
    }
}