﻿
namespace Main.Views
{
    /// <summary>
    ///     Interaction logic for CheckInBookView.xaml
    /// </summary>
    public partial class CheckInBookView 
    {
        public CheckInBookView()
        {
            InitializeComponent();
        }
    }
}