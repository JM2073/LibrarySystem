﻿
namespace Main.Views
{
    /// <summary>
    ///     Interaction logic for RegisterView.xaml
    /// </summary>
    public partial class RegisterView 
    {
        public RegisterView()
        {
            InitializeComponent();
        }
    }
}