﻿

namespace Main.Views
{
    /// <summary>
    ///     Interaction logic for CheckOutBookView.xaml
    /// </summary>
    public partial class CheckOutBookView 
    {
        public CheckOutBookView()
        {
            InitializeComponent();
        }
    }
}