﻿namespace Main.Servies
{
    public interface INavigationService
    {
        void Navigate();
    }
}