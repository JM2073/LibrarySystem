﻿namespace Main.Servies
{
    public class ReportService
    {
        
    }
}