﻿namespace Main.Stores
{
    public class SearchStore
    {
        public string SearchString { get; set; }
    }
}