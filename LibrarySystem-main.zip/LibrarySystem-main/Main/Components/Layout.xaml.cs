﻿

namespace Main.Components
{
    /// <summary>
    ///     Interaction logic for Layout.xaml
    /// </summary>
    public partial class Layout 
    {
        public Layout()
        {
            InitializeComponent();
        }
    }
}