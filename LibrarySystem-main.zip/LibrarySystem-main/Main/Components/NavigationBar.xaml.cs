﻿ 
namespace Main.Components
{
    /// <summary>
    ///     Interaction logic for NavigationBar.xaml
    /// </summary>
    public partial class NavigationBar 
    {
        public NavigationBar()
        {
            InitializeComponent();
        }
    }
}