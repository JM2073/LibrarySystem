﻿
namespace Main.Components
{
    /// <summary>
    ///     Interaction logic for SearchBar.xaml
    /// </summary>
    public partial class SearchBar
    {
        public SearchBar()
        {
            InitializeComponent();
        }
    }
}